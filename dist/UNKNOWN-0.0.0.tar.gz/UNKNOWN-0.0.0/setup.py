from distutils.core import setup
import glob

setup(
    # this is the file that is run when you start the game from the command line.
    console=["mario.py"],
    # data files - these are the non-python files, like images and sounds
    data_files=[
        (
            "data",
            glob.glob("data\\*.png") + glob.glob("data\\*.json") + glob.glob("data\\*.gif")
            + glob.glob("data\\*.jpg") + glob.glob("data\\*.PNG")
        ),
        #  ("sprites", glob.glob("sprites\\*.json")),
        (
            "sfx",
            glob.glob("sfx\\*.wav")),
        (
            "levels",
            glob.glob("levels\\*.json")
        ),
        #  ("img", glob.glob("img\\*.gif") + glob.glob("img\\*.png")),
        #  ("", ["settings.json"]),
    ],
)
